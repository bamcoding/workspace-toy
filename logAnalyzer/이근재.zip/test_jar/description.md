같은 경로에 있는 input.log 파일을 읽고 output.log 파일을 생성합니다.

이미 output.log 파일이 있다면 삭제하고 터미널 환경에서 아래 2가지 명령어 중 하나를 수행하세요.

1. sh test.sh
2. java -jar test.jar

